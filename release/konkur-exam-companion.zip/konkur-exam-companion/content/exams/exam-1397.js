(function registerExam1397(global) {
  "use strict";
  var app = global.KonkurApp;
  var timestamp = "2026-07-15T00:00:00.000Z";
  var config = {
  "year": 1397,
  "pdfUrl": "https://cshub.ir/wp-content/uploads/2024/08/97.pdf",
  "officialKeyUrl": "https://cshub.ir/wp-content/uploads/2025/01/COM_97_E_Key.pdf",
  "questionCount": 140,
  "sections": {
    "language": {
      "label": "زبان انگلیسی",
      "questions": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19,
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28,
        29,
        30
      ],
      "page": 2
    },
    "technical": {
      "label": "تمام سؤال‌های فنی پس از زبان",
      "questions": [
        31,
        32,
        33,
        34,
        35,
        36,
        37,
        38,
        39,
        40,
        41,
        42,
        43,
        44,
        45,
        46,
        47,
        48,
        49,
        50,
        51,
        52,
        53,
        54,
        55,
        56,
        57,
        58,
        59,
        60,
        61,
        62,
        63,
        64,
        65,
        66,
        67,
        68,
        69,
        70,
        71,
        72,
        73,
        74,
        75,
        76,
        77,
        78,
        79,
        80,
        81,
        82,
        83,
        84,
        85,
        86,
        87,
        88,
        89,
        90,
        91,
        92,
        93,
        94,
        95,
        96,
        97,
        98,
        99,
        100,
        101,
        102,
        103,
        104,
        105,
        106,
        107,
        108,
        109,
        110,
        111,
        112,
        113,
        114,
        115,
        116,
        117,
        118,
        119,
        120,
        121,
        122,
        123,
        124,
        125,
        126,
        127,
        128,
        129,
        130,
        131,
        132,
        133,
        134,
        135,
        136,
        137,
        138,
        139,
        140
      ],
      "page": 8
    },
    "all": {
      "label": "کل دفترچه و کلید کامل",
      "questions": [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
        19,
        20,
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28,
        29,
        30,
        31,
        32,
        33,
        34,
        35,
        36,
        37,
        38,
        39,
        40,
        41,
        42,
        43,
        44,
        45,
        46,
        47,
        48,
        49,
        50,
        51,
        52,
        53,
        54,
        55,
        56,
        57,
        58,
        59,
        60,
        61,
        62,
        63,
        64,
        65,
        66,
        67,
        68,
        69,
        70,
        71,
        72,
        73,
        74,
        75,
        76,
        77,
        78,
        79,
        80,
        81,
        82,
        83,
        84,
        85,
        86,
        87,
        88,
        89,
        90,
        91,
        92,
        93,
        94,
        95,
        96,
        97,
        98,
        99,
        100,
        101,
        102,
        103,
        104,
        105,
        106,
        107,
        108,
        109,
        110,
        111,
        112,
        113,
        114,
        115,
        116,
        117,
        118,
        119,
        120,
        121,
        122,
        123,
        124,
        125,
        126,
        127,
        128,
        129,
        130,
        131,
        132,
        133,
        134,
        135,
        136,
        137,
        138,
        139,
        140
      ],
      "page": 2
    }
  },
  "structureNote": "چینش دروس سال‌های قدیمی بین دفترچه‌ها و گرایش‌ها تغییر می‌کند؛ برای جلوگیری از برچسب اشتباه، کلید کامل و بازه دستی ارائه شده است.",
  "verificationStatus": "legacy-unverified",
  "sourceType": "legacy-prototype",
  "sourcePath": "legacy/konkur-developer-bank-v4.html"
};

  var sourceDataset = {
  "datasetId": "exam:1397:sources",
  "datasetType": "source-records",
  "schemaVersion": 1,
  "version": 1,
  "testOnly": false,
  "records": [
    {
      "id": "source:1397:paper:legacy",
      "recordKey": "source:1397:paper:legacy@1",
      "schemaVersion": 1,
      "version": 1,
      "year": 1397,
      "sourceType": "exam-paper",
      "title": "CE MSc 1397 exam-paper (legacy-unverified)",
      "paperSourceId": null,
      "answerKeySourceId": null,
      "correctionSourceIds": [],
      "publisher": "Legacy prototype (cshub.ir / mastertest.ir)",
      "retrievalDate": null,
      "localFilename": null,
      "originalUrl": "https://cshub.ir/wp-content/uploads/2024/08/97.pdf",
      "checksum": null,
      "verificationStatus": "legacy-unverified",
      "verificationNotes": "Extracted from legacy prototype. Not independently verified.",
      "licenseOrRedistributionNote": "Unknown — source URLs point to third-party hosting, not official publisher.",
      "questionNumberCoverage": [],
      "knownInconsistencies": [],
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z"
    },
    {
      "id": "source:1397:key:legacy",
      "recordKey": "source:1397:key:legacy@1",
      "schemaVersion": 1,
      "version": 1,
      "year": 1397,
      "sourceType": "answer-key",
      "title": "CE MSc 1397 answer-key (legacy-unverified)",
      "paperSourceId": "source:1397:paper:legacy",
      "answerKeySourceId": null,
      "correctionSourceIds": [],
      "publisher": "Legacy prototype (cshub.ir / mastertest.ir)",
      "retrievalDate": null,
      "localFilename": null,
      "originalUrl": "https://cshub.ir/wp-content/uploads/2025/01/COM_97_E_Key.pdf",
      "checksum": null,
      "verificationStatus": "legacy-unverified",
      "verificationNotes": "Extracted from legacy prototype. Not independently verified.",
      "licenseOrRedistributionNote": "Unknown — source URLs point to third-party hosting, not official publisher.",
      "questionNumberCoverage": [],
      "knownInconsistencies": [],
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z"
    }
  ]
};
  var questionDataset = {
  "datasetId": "exam:1397:questions",
  "datasetType": "questions",
  "schemaVersion": 1,
  "version": 1,
  "testOnly": false,
  "records": [
    {
      "id": "question:1397:ce-msc:1",
      "recordKey": "question:1397:ce-msc:1@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 1,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:1:option:a",
        "question:1397:ce-msc:1:option:b",
        "question:1397:ce-msc:1:option:c",
        "question:1397:ce-msc:1:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:1:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:2",
      "recordKey": "question:1397:ce-msc:2@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 2,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:2:option:a",
        "question:1397:ce-msc:2:option:b",
        "question:1397:ce-msc:2:option:c",
        "question:1397:ce-msc:2:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:2:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:3",
      "recordKey": "question:1397:ce-msc:3@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 3,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:3:option:a",
        "question:1397:ce-msc:3:option:b",
        "question:1397:ce-msc:3:option:c",
        "question:1397:ce-msc:3:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:3:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:4",
      "recordKey": "question:1397:ce-msc:4@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 4,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:4:option:a",
        "question:1397:ce-msc:4:option:b",
        "question:1397:ce-msc:4:option:c",
        "question:1397:ce-msc:4:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:4:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:5",
      "recordKey": "question:1397:ce-msc:5@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 5,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:5:option:a",
        "question:1397:ce-msc:5:option:b",
        "question:1397:ce-msc:5:option:c",
        "question:1397:ce-msc:5:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:5:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:6",
      "recordKey": "question:1397:ce-msc:6@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 6,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:6:option:a",
        "question:1397:ce-msc:6:option:b",
        "question:1397:ce-msc:6:option:c",
        "question:1397:ce-msc:6:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:6:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:7",
      "recordKey": "question:1397:ce-msc:7@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 7,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:7:option:a",
        "question:1397:ce-msc:7:option:b",
        "question:1397:ce-msc:7:option:c",
        "question:1397:ce-msc:7:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:7:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:8",
      "recordKey": "question:1397:ce-msc:8@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 8,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:8:option:a",
        "question:1397:ce-msc:8:option:b",
        "question:1397:ce-msc:8:option:c",
        "question:1397:ce-msc:8:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:8:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:9",
      "recordKey": "question:1397:ce-msc:9@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 9,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:9:option:a",
        "question:1397:ce-msc:9:option:b",
        "question:1397:ce-msc:9:option:c",
        "question:1397:ce-msc:9:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:9:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:10",
      "recordKey": "question:1397:ce-msc:10@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 10,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:10:option:a",
        "question:1397:ce-msc:10:option:b",
        "question:1397:ce-msc:10:option:c",
        "question:1397:ce-msc:10:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:10:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:11",
      "recordKey": "question:1397:ce-msc:11@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 11,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:11:option:a",
        "question:1397:ce-msc:11:option:b",
        "question:1397:ce-msc:11:option:c",
        "question:1397:ce-msc:11:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:11:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:12",
      "recordKey": "question:1397:ce-msc:12@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 12,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:12:option:a",
        "question:1397:ce-msc:12:option:b",
        "question:1397:ce-msc:12:option:c",
        "question:1397:ce-msc:12:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:12:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:13",
      "recordKey": "question:1397:ce-msc:13@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 13,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:13:option:a",
        "question:1397:ce-msc:13:option:b",
        "question:1397:ce-msc:13:option:c",
        "question:1397:ce-msc:13:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:13:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:14",
      "recordKey": "question:1397:ce-msc:14@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 14,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:14:option:a",
        "question:1397:ce-msc:14:option:b",
        "question:1397:ce-msc:14:option:c",
        "question:1397:ce-msc:14:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:14:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:15",
      "recordKey": "question:1397:ce-msc:15@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 15,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:15:option:a",
        "question:1397:ce-msc:15:option:b",
        "question:1397:ce-msc:15:option:c",
        "question:1397:ce-msc:15:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:15:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:16",
      "recordKey": "question:1397:ce-msc:16@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 16,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:16:option:a",
        "question:1397:ce-msc:16:option:b",
        "question:1397:ce-msc:16:option:c",
        "question:1397:ce-msc:16:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:16:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:17",
      "recordKey": "question:1397:ce-msc:17@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 17,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:17:option:a",
        "question:1397:ce-msc:17:option:b",
        "question:1397:ce-msc:17:option:c",
        "question:1397:ce-msc:17:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:17:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:18",
      "recordKey": "question:1397:ce-msc:18@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 18,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:18:option:a",
        "question:1397:ce-msc:18:option:b",
        "question:1397:ce-msc:18:option:c",
        "question:1397:ce-msc:18:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:18:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:19",
      "recordKey": "question:1397:ce-msc:19@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 19,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:19:option:a",
        "question:1397:ce-msc:19:option:b",
        "question:1397:ce-msc:19:option:c",
        "question:1397:ce-msc:19:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:19:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:20",
      "recordKey": "question:1397:ce-msc:20@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 20,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:20:option:a",
        "question:1397:ce-msc:20:option:b",
        "question:1397:ce-msc:20:option:c",
        "question:1397:ce-msc:20:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:20:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:21",
      "recordKey": "question:1397:ce-msc:21@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 21,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:21:option:a",
        "question:1397:ce-msc:21:option:b",
        "question:1397:ce-msc:21:option:c",
        "question:1397:ce-msc:21:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:21:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:22",
      "recordKey": "question:1397:ce-msc:22@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 22,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:22:option:a",
        "question:1397:ce-msc:22:option:b",
        "question:1397:ce-msc:22:option:c",
        "question:1397:ce-msc:22:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:22:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:23",
      "recordKey": "question:1397:ce-msc:23@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 23,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:23:option:a",
        "question:1397:ce-msc:23:option:b",
        "question:1397:ce-msc:23:option:c",
        "question:1397:ce-msc:23:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:23:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:24",
      "recordKey": "question:1397:ce-msc:24@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 24,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:24:option:a",
        "question:1397:ce-msc:24:option:b",
        "question:1397:ce-msc:24:option:c",
        "question:1397:ce-msc:24:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:24:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:25",
      "recordKey": "question:1397:ce-msc:25@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 25,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:25:option:a",
        "question:1397:ce-msc:25:option:b",
        "question:1397:ce-msc:25:option:c",
        "question:1397:ce-msc:25:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:25:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:26",
      "recordKey": "question:1397:ce-msc:26@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 26,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:26:option:a",
        "question:1397:ce-msc:26:option:b",
        "question:1397:ce-msc:26:option:c",
        "question:1397:ce-msc:26:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:26:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:27",
      "recordKey": "question:1397:ce-msc:27@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 27,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:27:option:a",
        "question:1397:ce-msc:27:option:b",
        "question:1397:ce-msc:27:option:c",
        "question:1397:ce-msc:27:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:27:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:28",
      "recordKey": "question:1397:ce-msc:28@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 28,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:28:option:a",
        "question:1397:ce-msc:28:option:b",
        "question:1397:ce-msc:28:option:c",
        "question:1397:ce-msc:28:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:28:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:29",
      "recordKey": "question:1397:ce-msc:29@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 29,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:29:option:a",
        "question:1397:ce-msc:29:option:b",
        "question:1397:ce-msc:29:option:c",
        "question:1397:ce-msc:29:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:29:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:30",
      "recordKey": "question:1397:ce-msc:30@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 30,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:30:option:a",
        "question:1397:ce-msc:30:option:b",
        "question:1397:ce-msc:30:option:c",
        "question:1397:ce-msc:30:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:30:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:31",
      "recordKey": "question:1397:ce-msc:31@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 31,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:31:option:a",
        "question:1397:ce-msc:31:option:b",
        "question:1397:ce-msc:31:option:c",
        "question:1397:ce-msc:31:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:31:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:32",
      "recordKey": "question:1397:ce-msc:32@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 32,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:32:option:a",
        "question:1397:ce-msc:32:option:b",
        "question:1397:ce-msc:32:option:c",
        "question:1397:ce-msc:32:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:32:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:33",
      "recordKey": "question:1397:ce-msc:33@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 33,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:33:option:a",
        "question:1397:ce-msc:33:option:b",
        "question:1397:ce-msc:33:option:c",
        "question:1397:ce-msc:33:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:33:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:34",
      "recordKey": "question:1397:ce-msc:34@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 34,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:34:option:a",
        "question:1397:ce-msc:34:option:b",
        "question:1397:ce-msc:34:option:c",
        "question:1397:ce-msc:34:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:34:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:35",
      "recordKey": "question:1397:ce-msc:35@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 35,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:35:option:a",
        "question:1397:ce-msc:35:option:b",
        "question:1397:ce-msc:35:option:c",
        "question:1397:ce-msc:35:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:35:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:36",
      "recordKey": "question:1397:ce-msc:36@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 36,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:36:option:a",
        "question:1397:ce-msc:36:option:b",
        "question:1397:ce-msc:36:option:c",
        "question:1397:ce-msc:36:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:36:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:37",
      "recordKey": "question:1397:ce-msc:37@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 37,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:37:option:a",
        "question:1397:ce-msc:37:option:b",
        "question:1397:ce-msc:37:option:c",
        "question:1397:ce-msc:37:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:37:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:38",
      "recordKey": "question:1397:ce-msc:38@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 38,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:38:option:a",
        "question:1397:ce-msc:38:option:b",
        "question:1397:ce-msc:38:option:c",
        "question:1397:ce-msc:38:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:38:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:39",
      "recordKey": "question:1397:ce-msc:39@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 39,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:39:option:a",
        "question:1397:ce-msc:39:option:b",
        "question:1397:ce-msc:39:option:c",
        "question:1397:ce-msc:39:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:39:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:40",
      "recordKey": "question:1397:ce-msc:40@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 40,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:40:option:a",
        "question:1397:ce-msc:40:option:b",
        "question:1397:ce-msc:40:option:c",
        "question:1397:ce-msc:40:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:40:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:41",
      "recordKey": "question:1397:ce-msc:41@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 41,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:41:option:a",
        "question:1397:ce-msc:41:option:b",
        "question:1397:ce-msc:41:option:c",
        "question:1397:ce-msc:41:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:41:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:42",
      "recordKey": "question:1397:ce-msc:42@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 42,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:42:option:a",
        "question:1397:ce-msc:42:option:b",
        "question:1397:ce-msc:42:option:c",
        "question:1397:ce-msc:42:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:42:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:43",
      "recordKey": "question:1397:ce-msc:43@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 43,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:43:option:a",
        "question:1397:ce-msc:43:option:b",
        "question:1397:ce-msc:43:option:c",
        "question:1397:ce-msc:43:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:43:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:44",
      "recordKey": "question:1397:ce-msc:44@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 44,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:44:option:a",
        "question:1397:ce-msc:44:option:b",
        "question:1397:ce-msc:44:option:c",
        "question:1397:ce-msc:44:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:44:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:45",
      "recordKey": "question:1397:ce-msc:45@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 45,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:45:option:a",
        "question:1397:ce-msc:45:option:b",
        "question:1397:ce-msc:45:option:c",
        "question:1397:ce-msc:45:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:45:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:46",
      "recordKey": "question:1397:ce-msc:46@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 46,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:46:option:a",
        "question:1397:ce-msc:46:option:b",
        "question:1397:ce-msc:46:option:c",
        "question:1397:ce-msc:46:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:46:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:47",
      "recordKey": "question:1397:ce-msc:47@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 47,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:47:option:a",
        "question:1397:ce-msc:47:option:b",
        "question:1397:ce-msc:47:option:c",
        "question:1397:ce-msc:47:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:47:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:48",
      "recordKey": "question:1397:ce-msc:48@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 48,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:48:option:a",
        "question:1397:ce-msc:48:option:b",
        "question:1397:ce-msc:48:option:c",
        "question:1397:ce-msc:48:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:48:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:49",
      "recordKey": "question:1397:ce-msc:49@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 49,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:49:option:a",
        "question:1397:ce-msc:49:option:b",
        "question:1397:ce-msc:49:option:c",
        "question:1397:ce-msc:49:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:49:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:50",
      "recordKey": "question:1397:ce-msc:50@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 50,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:50:option:a",
        "question:1397:ce-msc:50:option:b",
        "question:1397:ce-msc:50:option:c",
        "question:1397:ce-msc:50:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:50:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:51",
      "recordKey": "question:1397:ce-msc:51@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 51,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:51:option:a",
        "question:1397:ce-msc:51:option:b",
        "question:1397:ce-msc:51:option:c",
        "question:1397:ce-msc:51:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:51:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:52",
      "recordKey": "question:1397:ce-msc:52@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 52,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:52:option:a",
        "question:1397:ce-msc:52:option:b",
        "question:1397:ce-msc:52:option:c",
        "question:1397:ce-msc:52:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:52:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:53",
      "recordKey": "question:1397:ce-msc:53@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 53,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:53:option:a",
        "question:1397:ce-msc:53:option:b",
        "question:1397:ce-msc:53:option:c",
        "question:1397:ce-msc:53:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:53:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:54",
      "recordKey": "question:1397:ce-msc:54@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 54,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:54:option:a",
        "question:1397:ce-msc:54:option:b",
        "question:1397:ce-msc:54:option:c",
        "question:1397:ce-msc:54:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:54:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:55",
      "recordKey": "question:1397:ce-msc:55@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 55,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:55:option:a",
        "question:1397:ce-msc:55:option:b",
        "question:1397:ce-msc:55:option:c",
        "question:1397:ce-msc:55:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:55:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:56",
      "recordKey": "question:1397:ce-msc:56@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 56,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:56:option:a",
        "question:1397:ce-msc:56:option:b",
        "question:1397:ce-msc:56:option:c",
        "question:1397:ce-msc:56:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:56:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:57",
      "recordKey": "question:1397:ce-msc:57@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 57,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:57:option:a",
        "question:1397:ce-msc:57:option:b",
        "question:1397:ce-msc:57:option:c",
        "question:1397:ce-msc:57:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:57:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:58",
      "recordKey": "question:1397:ce-msc:58@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 58,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:58:option:a",
        "question:1397:ce-msc:58:option:b",
        "question:1397:ce-msc:58:option:c",
        "question:1397:ce-msc:58:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:58:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:59",
      "recordKey": "question:1397:ce-msc:59@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 59,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:59:option:a",
        "question:1397:ce-msc:59:option:b",
        "question:1397:ce-msc:59:option:c",
        "question:1397:ce-msc:59:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:59:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:60",
      "recordKey": "question:1397:ce-msc:60@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 60,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:60:option:a",
        "question:1397:ce-msc:60:option:b",
        "question:1397:ce-msc:60:option:c",
        "question:1397:ce-msc:60:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:60:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:61",
      "recordKey": "question:1397:ce-msc:61@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 61,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:61:option:a",
        "question:1397:ce-msc:61:option:b",
        "question:1397:ce-msc:61:option:c",
        "question:1397:ce-msc:61:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:61:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:62",
      "recordKey": "question:1397:ce-msc:62@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 62,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:62:option:a",
        "question:1397:ce-msc:62:option:b",
        "question:1397:ce-msc:62:option:c",
        "question:1397:ce-msc:62:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:62:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:63",
      "recordKey": "question:1397:ce-msc:63@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 63,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:63:option:a",
        "question:1397:ce-msc:63:option:b",
        "question:1397:ce-msc:63:option:c",
        "question:1397:ce-msc:63:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:63:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:64",
      "recordKey": "question:1397:ce-msc:64@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 64,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:64:option:a",
        "question:1397:ce-msc:64:option:b",
        "question:1397:ce-msc:64:option:c",
        "question:1397:ce-msc:64:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:64:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:65",
      "recordKey": "question:1397:ce-msc:65@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 65,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:65:option:a",
        "question:1397:ce-msc:65:option:b",
        "question:1397:ce-msc:65:option:c",
        "question:1397:ce-msc:65:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:65:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:66",
      "recordKey": "question:1397:ce-msc:66@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 66,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:66:option:a",
        "question:1397:ce-msc:66:option:b",
        "question:1397:ce-msc:66:option:c",
        "question:1397:ce-msc:66:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:66:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:67",
      "recordKey": "question:1397:ce-msc:67@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 67,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:67:option:a",
        "question:1397:ce-msc:67:option:b",
        "question:1397:ce-msc:67:option:c",
        "question:1397:ce-msc:67:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:67:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:68",
      "recordKey": "question:1397:ce-msc:68@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 68,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:68:option:a",
        "question:1397:ce-msc:68:option:b",
        "question:1397:ce-msc:68:option:c",
        "question:1397:ce-msc:68:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:68:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:69",
      "recordKey": "question:1397:ce-msc:69@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 69,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:69:option:a",
        "question:1397:ce-msc:69:option:b",
        "question:1397:ce-msc:69:option:c",
        "question:1397:ce-msc:69:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:69:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:70",
      "recordKey": "question:1397:ce-msc:70@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 70,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:70:option:a",
        "question:1397:ce-msc:70:option:b",
        "question:1397:ce-msc:70:option:c",
        "question:1397:ce-msc:70:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:70:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:71",
      "recordKey": "question:1397:ce-msc:71@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 71,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:71:option:a",
        "question:1397:ce-msc:71:option:b",
        "question:1397:ce-msc:71:option:c",
        "question:1397:ce-msc:71:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:71:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:72",
      "recordKey": "question:1397:ce-msc:72@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 72,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:72:option:a",
        "question:1397:ce-msc:72:option:b",
        "question:1397:ce-msc:72:option:c",
        "question:1397:ce-msc:72:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:72:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:73",
      "recordKey": "question:1397:ce-msc:73@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 73,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:73:option:a",
        "question:1397:ce-msc:73:option:b",
        "question:1397:ce-msc:73:option:c",
        "question:1397:ce-msc:73:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:73:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:74",
      "recordKey": "question:1397:ce-msc:74@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 74,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:74:option:a",
        "question:1397:ce-msc:74:option:b",
        "question:1397:ce-msc:74:option:c",
        "question:1397:ce-msc:74:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:74:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:75",
      "recordKey": "question:1397:ce-msc:75@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 75,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:75:option:a",
        "question:1397:ce-msc:75:option:b",
        "question:1397:ce-msc:75:option:c",
        "question:1397:ce-msc:75:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:75:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:76",
      "recordKey": "question:1397:ce-msc:76@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 76,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:76:option:a",
        "question:1397:ce-msc:76:option:b",
        "question:1397:ce-msc:76:option:c",
        "question:1397:ce-msc:76:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:76:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:77",
      "recordKey": "question:1397:ce-msc:77@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 77,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:77:option:a",
        "question:1397:ce-msc:77:option:b",
        "question:1397:ce-msc:77:option:c",
        "question:1397:ce-msc:77:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:77:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:78",
      "recordKey": "question:1397:ce-msc:78@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 78,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:78:option:a",
        "question:1397:ce-msc:78:option:b",
        "question:1397:ce-msc:78:option:c",
        "question:1397:ce-msc:78:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:78:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:79",
      "recordKey": "question:1397:ce-msc:79@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 79,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:79:option:a",
        "question:1397:ce-msc:79:option:b",
        "question:1397:ce-msc:79:option:c",
        "question:1397:ce-msc:79:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:79:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:80",
      "recordKey": "question:1397:ce-msc:80@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 80,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:80:option:a",
        "question:1397:ce-msc:80:option:b",
        "question:1397:ce-msc:80:option:c",
        "question:1397:ce-msc:80:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:80:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:81",
      "recordKey": "question:1397:ce-msc:81@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 81,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:81:option:a",
        "question:1397:ce-msc:81:option:b",
        "question:1397:ce-msc:81:option:c",
        "question:1397:ce-msc:81:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:81:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:82",
      "recordKey": "question:1397:ce-msc:82@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 82,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:82:option:a",
        "question:1397:ce-msc:82:option:b",
        "question:1397:ce-msc:82:option:c",
        "question:1397:ce-msc:82:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:82:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:83",
      "recordKey": "question:1397:ce-msc:83@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 83,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:83:option:a",
        "question:1397:ce-msc:83:option:b",
        "question:1397:ce-msc:83:option:c",
        "question:1397:ce-msc:83:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:83:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:84",
      "recordKey": "question:1397:ce-msc:84@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 84,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:84:option:a",
        "question:1397:ce-msc:84:option:b",
        "question:1397:ce-msc:84:option:c",
        "question:1397:ce-msc:84:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:84:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:85",
      "recordKey": "question:1397:ce-msc:85@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 85,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:85:option:a",
        "question:1397:ce-msc:85:option:b",
        "question:1397:ce-msc:85:option:c",
        "question:1397:ce-msc:85:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:85:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:86",
      "recordKey": "question:1397:ce-msc:86@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 86,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:86:option:a",
        "question:1397:ce-msc:86:option:b",
        "question:1397:ce-msc:86:option:c",
        "question:1397:ce-msc:86:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:86:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:87",
      "recordKey": "question:1397:ce-msc:87@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 87,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:87:option:a",
        "question:1397:ce-msc:87:option:b",
        "question:1397:ce-msc:87:option:c",
        "question:1397:ce-msc:87:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:87:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:88",
      "recordKey": "question:1397:ce-msc:88@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 88,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:88:option:a",
        "question:1397:ce-msc:88:option:b",
        "question:1397:ce-msc:88:option:c",
        "question:1397:ce-msc:88:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:88:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:89",
      "recordKey": "question:1397:ce-msc:89@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 89,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:89:option:a",
        "question:1397:ce-msc:89:option:b",
        "question:1397:ce-msc:89:option:c",
        "question:1397:ce-msc:89:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:89:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:90",
      "recordKey": "question:1397:ce-msc:90@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 90,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:90:option:a",
        "question:1397:ce-msc:90:option:b",
        "question:1397:ce-msc:90:option:c",
        "question:1397:ce-msc:90:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:90:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:91",
      "recordKey": "question:1397:ce-msc:91@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 91,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:91:option:a",
        "question:1397:ce-msc:91:option:b",
        "question:1397:ce-msc:91:option:c",
        "question:1397:ce-msc:91:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:91:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:92",
      "recordKey": "question:1397:ce-msc:92@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 92,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:92:option:a",
        "question:1397:ce-msc:92:option:b",
        "question:1397:ce-msc:92:option:c",
        "question:1397:ce-msc:92:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:92:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:93",
      "recordKey": "question:1397:ce-msc:93@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 93,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:93:option:a",
        "question:1397:ce-msc:93:option:b",
        "question:1397:ce-msc:93:option:c",
        "question:1397:ce-msc:93:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:93:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:94",
      "recordKey": "question:1397:ce-msc:94@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 94,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:94:option:a",
        "question:1397:ce-msc:94:option:b",
        "question:1397:ce-msc:94:option:c",
        "question:1397:ce-msc:94:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:94:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:95",
      "recordKey": "question:1397:ce-msc:95@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 95,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:95:option:a",
        "question:1397:ce-msc:95:option:b",
        "question:1397:ce-msc:95:option:c",
        "question:1397:ce-msc:95:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:95:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:96",
      "recordKey": "question:1397:ce-msc:96@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 96,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:96:option:a",
        "question:1397:ce-msc:96:option:b",
        "question:1397:ce-msc:96:option:c",
        "question:1397:ce-msc:96:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:96:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:97",
      "recordKey": "question:1397:ce-msc:97@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 97,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:97:option:a",
        "question:1397:ce-msc:97:option:b",
        "question:1397:ce-msc:97:option:c",
        "question:1397:ce-msc:97:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:97:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:98",
      "recordKey": "question:1397:ce-msc:98@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 98,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:98:option:a",
        "question:1397:ce-msc:98:option:b",
        "question:1397:ce-msc:98:option:c",
        "question:1397:ce-msc:98:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:98:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:99",
      "recordKey": "question:1397:ce-msc:99@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 99,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:99:option:a",
        "question:1397:ce-msc:99:option:b",
        "question:1397:ce-msc:99:option:c",
        "question:1397:ce-msc:99:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:99:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:100",
      "recordKey": "question:1397:ce-msc:100@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 100,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:100:option:a",
        "question:1397:ce-msc:100:option:b",
        "question:1397:ce-msc:100:option:c",
        "question:1397:ce-msc:100:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:100:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:101",
      "recordKey": "question:1397:ce-msc:101@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 101,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:101:option:a",
        "question:1397:ce-msc:101:option:b",
        "question:1397:ce-msc:101:option:c",
        "question:1397:ce-msc:101:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:101:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:102",
      "recordKey": "question:1397:ce-msc:102@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 102,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:102:option:a",
        "question:1397:ce-msc:102:option:b",
        "question:1397:ce-msc:102:option:c",
        "question:1397:ce-msc:102:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:102:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:103",
      "recordKey": "question:1397:ce-msc:103@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 103,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:103:option:a",
        "question:1397:ce-msc:103:option:b",
        "question:1397:ce-msc:103:option:c",
        "question:1397:ce-msc:103:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:103:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:104",
      "recordKey": "question:1397:ce-msc:104@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 104,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:104:option:a",
        "question:1397:ce-msc:104:option:b",
        "question:1397:ce-msc:104:option:c",
        "question:1397:ce-msc:104:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:104:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:105",
      "recordKey": "question:1397:ce-msc:105@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 105,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:105:option:a",
        "question:1397:ce-msc:105:option:b",
        "question:1397:ce-msc:105:option:c",
        "question:1397:ce-msc:105:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:105:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:106",
      "recordKey": "question:1397:ce-msc:106@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 106,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:106:option:a",
        "question:1397:ce-msc:106:option:b",
        "question:1397:ce-msc:106:option:c",
        "question:1397:ce-msc:106:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:106:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:107",
      "recordKey": "question:1397:ce-msc:107@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 107,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:107:option:a",
        "question:1397:ce-msc:107:option:b",
        "question:1397:ce-msc:107:option:c",
        "question:1397:ce-msc:107:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:107:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:108",
      "recordKey": "question:1397:ce-msc:108@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 108,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:108:option:a",
        "question:1397:ce-msc:108:option:b",
        "question:1397:ce-msc:108:option:c",
        "question:1397:ce-msc:108:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:108:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:109",
      "recordKey": "question:1397:ce-msc:109@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 109,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:109:option:a",
        "question:1397:ce-msc:109:option:b",
        "question:1397:ce-msc:109:option:c",
        "question:1397:ce-msc:109:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:109:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:110",
      "recordKey": "question:1397:ce-msc:110@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 110,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:110:option:a",
        "question:1397:ce-msc:110:option:b",
        "question:1397:ce-msc:110:option:c",
        "question:1397:ce-msc:110:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:110:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:111",
      "recordKey": "question:1397:ce-msc:111@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 111,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:111:option:a",
        "question:1397:ce-msc:111:option:b",
        "question:1397:ce-msc:111:option:c",
        "question:1397:ce-msc:111:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:111:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:112",
      "recordKey": "question:1397:ce-msc:112@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 112,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:112:option:a",
        "question:1397:ce-msc:112:option:b",
        "question:1397:ce-msc:112:option:c",
        "question:1397:ce-msc:112:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:112:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:113",
      "recordKey": "question:1397:ce-msc:113@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 113,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:113:option:a",
        "question:1397:ce-msc:113:option:b",
        "question:1397:ce-msc:113:option:c",
        "question:1397:ce-msc:113:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:113:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:114",
      "recordKey": "question:1397:ce-msc:114@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 114,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:114:option:a",
        "question:1397:ce-msc:114:option:b",
        "question:1397:ce-msc:114:option:c",
        "question:1397:ce-msc:114:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:114:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:115",
      "recordKey": "question:1397:ce-msc:115@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 115,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:115:option:a",
        "question:1397:ce-msc:115:option:b",
        "question:1397:ce-msc:115:option:c",
        "question:1397:ce-msc:115:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:115:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:116",
      "recordKey": "question:1397:ce-msc:116@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 116,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:116:option:a",
        "question:1397:ce-msc:116:option:b",
        "question:1397:ce-msc:116:option:c",
        "question:1397:ce-msc:116:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:116:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:117",
      "recordKey": "question:1397:ce-msc:117@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 117,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:117:option:a",
        "question:1397:ce-msc:117:option:b",
        "question:1397:ce-msc:117:option:c",
        "question:1397:ce-msc:117:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:117:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:118",
      "recordKey": "question:1397:ce-msc:118@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 118,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:118:option:a",
        "question:1397:ce-msc:118:option:b",
        "question:1397:ce-msc:118:option:c",
        "question:1397:ce-msc:118:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:118:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:119",
      "recordKey": "question:1397:ce-msc:119@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 119,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:119:option:a",
        "question:1397:ce-msc:119:option:b",
        "question:1397:ce-msc:119:option:c",
        "question:1397:ce-msc:119:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:119:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:120",
      "recordKey": "question:1397:ce-msc:120@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 120,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:120:option:a",
        "question:1397:ce-msc:120:option:b",
        "question:1397:ce-msc:120:option:c",
        "question:1397:ce-msc:120:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:120:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:121",
      "recordKey": "question:1397:ce-msc:121@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 121,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:121:option:a",
        "question:1397:ce-msc:121:option:b",
        "question:1397:ce-msc:121:option:c",
        "question:1397:ce-msc:121:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:121:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:122",
      "recordKey": "question:1397:ce-msc:122@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 122,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:122:option:a",
        "question:1397:ce-msc:122:option:b",
        "question:1397:ce-msc:122:option:c",
        "question:1397:ce-msc:122:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:122:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:123",
      "recordKey": "question:1397:ce-msc:123@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 123,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:123:option:a",
        "question:1397:ce-msc:123:option:b",
        "question:1397:ce-msc:123:option:c",
        "question:1397:ce-msc:123:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:123:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:124",
      "recordKey": "question:1397:ce-msc:124@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 124,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:124:option:a",
        "question:1397:ce-msc:124:option:b",
        "question:1397:ce-msc:124:option:c",
        "question:1397:ce-msc:124:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:124:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:125",
      "recordKey": "question:1397:ce-msc:125@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 125,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:125:option:a",
        "question:1397:ce-msc:125:option:b",
        "question:1397:ce-msc:125:option:c",
        "question:1397:ce-msc:125:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:125:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:126",
      "recordKey": "question:1397:ce-msc:126@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 126,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:126:option:a",
        "question:1397:ce-msc:126:option:b",
        "question:1397:ce-msc:126:option:c",
        "question:1397:ce-msc:126:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:126:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:127",
      "recordKey": "question:1397:ce-msc:127@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 127,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:127:option:a",
        "question:1397:ce-msc:127:option:b",
        "question:1397:ce-msc:127:option:c",
        "question:1397:ce-msc:127:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:127:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:128",
      "recordKey": "question:1397:ce-msc:128@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 128,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:128:option:a",
        "question:1397:ce-msc:128:option:b",
        "question:1397:ce-msc:128:option:c",
        "question:1397:ce-msc:128:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:128:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:129",
      "recordKey": "question:1397:ce-msc:129@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 129,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:129:option:a",
        "question:1397:ce-msc:129:option:b",
        "question:1397:ce-msc:129:option:c",
        "question:1397:ce-msc:129:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:129:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:130",
      "recordKey": "question:1397:ce-msc:130@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 130,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:130:option:a",
        "question:1397:ce-msc:130:option:b",
        "question:1397:ce-msc:130:option:c",
        "question:1397:ce-msc:130:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:130:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:131",
      "recordKey": "question:1397:ce-msc:131@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 131,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:131:option:a",
        "question:1397:ce-msc:131:option:b",
        "question:1397:ce-msc:131:option:c",
        "question:1397:ce-msc:131:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:131:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:132",
      "recordKey": "question:1397:ce-msc:132@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 132,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:132:option:a",
        "question:1397:ce-msc:132:option:b",
        "question:1397:ce-msc:132:option:c",
        "question:1397:ce-msc:132:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:132:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:133",
      "recordKey": "question:1397:ce-msc:133@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 133,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:133:option:a",
        "question:1397:ce-msc:133:option:b",
        "question:1397:ce-msc:133:option:c",
        "question:1397:ce-msc:133:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:133:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:134",
      "recordKey": "question:1397:ce-msc:134@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 134,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:134:option:a",
        "question:1397:ce-msc:134:option:b",
        "question:1397:ce-msc:134:option:c",
        "question:1397:ce-msc:134:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:134:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:135",
      "recordKey": "question:1397:ce-msc:135@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 135,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:135:option:a",
        "question:1397:ce-msc:135:option:b",
        "question:1397:ce-msc:135:option:c",
        "question:1397:ce-msc:135:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:135:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:136",
      "recordKey": "question:1397:ce-msc:136@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 136,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:136:option:a",
        "question:1397:ce-msc:136:option:b",
        "question:1397:ce-msc:136:option:c",
        "question:1397:ce-msc:136:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:136:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:137",
      "recordKey": "question:1397:ce-msc:137@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 137,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:137:option:a",
        "question:1397:ce-msc:137:option:b",
        "question:1397:ce-msc:137:option:c",
        "question:1397:ce-msc:137:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:137:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:138",
      "recordKey": "question:1397:ce-msc:138@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 138,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:138:option:a",
        "question:1397:ce-msc:138:option:b",
        "question:1397:ce-msc:138:option:c",
        "question:1397:ce-msc:138:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:138:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:139",
      "recordKey": "question:1397:ce-msc:139@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 139,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:139:option:a",
        "question:1397:ce-msc:139:option:b",
        "question:1397:ce-msc:139:option:c",
        "question:1397:ce-msc:139:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:139:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    },
    {
      "id": "question:1397:ce-msc:140",
      "recordKey": "question:1397:ce-msc:140@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:paper:legacy"
      ],
      "primarySourceId": "source:1397:paper:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype. Question text not transcribed — see PDF.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "year": 1397,
      "paperCode": "ce-msc",
      "questionNumber": 140,
      "subjectId": null,
      "topicIds": [],
      "contentStatus": "text-unavailable",
      "responseMode": "single-choice",
      "text": null,
      "imageAssetIds": [],
      "optionIds": [
        "question:1397:ce-msc:140:option:a",
        "question:1397:ce-msc:140:option:b",
        "question:1397:ce-msc:140:option:c",
        "question:1397:ce-msc:140:option:d"
      ],
      "questionStatus": "active",
      "officialAnswerIds": [
        "answer:1397:140:legacy-key"
      ],
      "officialCorrectionIds": [],
      "explanationStatus": "missing",
      "explanationId": null
    }
  ]
};
  var optionDataset = {
  "datasetId": "exam:1397:options",
  "datasetType": "question-options",
  "schemaVersion": 1,
  "version": 1,
  "testOnly": false,
  "records": [
    {
      "id": "question:1397:ce-msc:1:option:a",
      "recordKey": "question:1397:ce-msc:1:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:1",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:1:option:b",
      "recordKey": "question:1397:ce-msc:1:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:1",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:1:option:c",
      "recordKey": "question:1397:ce-msc:1:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:1",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:1:option:d",
      "recordKey": "question:1397:ce-msc:1:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:1",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:2:option:a",
      "recordKey": "question:1397:ce-msc:2:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:2",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:2:option:b",
      "recordKey": "question:1397:ce-msc:2:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:2",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:2:option:c",
      "recordKey": "question:1397:ce-msc:2:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:2",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:2:option:d",
      "recordKey": "question:1397:ce-msc:2:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:2",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:3:option:a",
      "recordKey": "question:1397:ce-msc:3:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:3",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:3:option:b",
      "recordKey": "question:1397:ce-msc:3:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:3",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:3:option:c",
      "recordKey": "question:1397:ce-msc:3:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:3",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:3:option:d",
      "recordKey": "question:1397:ce-msc:3:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:3",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:4:option:a",
      "recordKey": "question:1397:ce-msc:4:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:4",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:4:option:b",
      "recordKey": "question:1397:ce-msc:4:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:4",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:4:option:c",
      "recordKey": "question:1397:ce-msc:4:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:4",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:4:option:d",
      "recordKey": "question:1397:ce-msc:4:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:4",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:5:option:a",
      "recordKey": "question:1397:ce-msc:5:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:5",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:5:option:b",
      "recordKey": "question:1397:ce-msc:5:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:5",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:5:option:c",
      "recordKey": "question:1397:ce-msc:5:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:5",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:5:option:d",
      "recordKey": "question:1397:ce-msc:5:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:5",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:6:option:a",
      "recordKey": "question:1397:ce-msc:6:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:6",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:6:option:b",
      "recordKey": "question:1397:ce-msc:6:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:6",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:6:option:c",
      "recordKey": "question:1397:ce-msc:6:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:6",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:6:option:d",
      "recordKey": "question:1397:ce-msc:6:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:6",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:7:option:a",
      "recordKey": "question:1397:ce-msc:7:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:7",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:7:option:b",
      "recordKey": "question:1397:ce-msc:7:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:7",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:7:option:c",
      "recordKey": "question:1397:ce-msc:7:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:7",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:7:option:d",
      "recordKey": "question:1397:ce-msc:7:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:7",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:8:option:a",
      "recordKey": "question:1397:ce-msc:8:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:8",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:8:option:b",
      "recordKey": "question:1397:ce-msc:8:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:8",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:8:option:c",
      "recordKey": "question:1397:ce-msc:8:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:8",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:8:option:d",
      "recordKey": "question:1397:ce-msc:8:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:8",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:9:option:a",
      "recordKey": "question:1397:ce-msc:9:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:9",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:9:option:b",
      "recordKey": "question:1397:ce-msc:9:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:9",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:9:option:c",
      "recordKey": "question:1397:ce-msc:9:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:9",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:9:option:d",
      "recordKey": "question:1397:ce-msc:9:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:9",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:10:option:a",
      "recordKey": "question:1397:ce-msc:10:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:10",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:10:option:b",
      "recordKey": "question:1397:ce-msc:10:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:10",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:10:option:c",
      "recordKey": "question:1397:ce-msc:10:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:10",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:10:option:d",
      "recordKey": "question:1397:ce-msc:10:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:10",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:11:option:a",
      "recordKey": "question:1397:ce-msc:11:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:11",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:11:option:b",
      "recordKey": "question:1397:ce-msc:11:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:11",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:11:option:c",
      "recordKey": "question:1397:ce-msc:11:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:11",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:11:option:d",
      "recordKey": "question:1397:ce-msc:11:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:11",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:12:option:a",
      "recordKey": "question:1397:ce-msc:12:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:12",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:12:option:b",
      "recordKey": "question:1397:ce-msc:12:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:12",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:12:option:c",
      "recordKey": "question:1397:ce-msc:12:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:12",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:12:option:d",
      "recordKey": "question:1397:ce-msc:12:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:12",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:13:option:a",
      "recordKey": "question:1397:ce-msc:13:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:13",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:13:option:b",
      "recordKey": "question:1397:ce-msc:13:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:13",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:13:option:c",
      "recordKey": "question:1397:ce-msc:13:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:13",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:13:option:d",
      "recordKey": "question:1397:ce-msc:13:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:13",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:14:option:a",
      "recordKey": "question:1397:ce-msc:14:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:14",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:14:option:b",
      "recordKey": "question:1397:ce-msc:14:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:14",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:14:option:c",
      "recordKey": "question:1397:ce-msc:14:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:14",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:14:option:d",
      "recordKey": "question:1397:ce-msc:14:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:14",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:15:option:a",
      "recordKey": "question:1397:ce-msc:15:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:15",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:15:option:b",
      "recordKey": "question:1397:ce-msc:15:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:15",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:15:option:c",
      "recordKey": "question:1397:ce-msc:15:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:15",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:15:option:d",
      "recordKey": "question:1397:ce-msc:15:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:15",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:16:option:a",
      "recordKey": "question:1397:ce-msc:16:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:16",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:16:option:b",
      "recordKey": "question:1397:ce-msc:16:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:16",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:16:option:c",
      "recordKey": "question:1397:ce-msc:16:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:16",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:16:option:d",
      "recordKey": "question:1397:ce-msc:16:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:16",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:17:option:a",
      "recordKey": "question:1397:ce-msc:17:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:17",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:17:option:b",
      "recordKey": "question:1397:ce-msc:17:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:17",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:17:option:c",
      "recordKey": "question:1397:ce-msc:17:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:17",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:17:option:d",
      "recordKey": "question:1397:ce-msc:17:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:17",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:18:option:a",
      "recordKey": "question:1397:ce-msc:18:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:18",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:18:option:b",
      "recordKey": "question:1397:ce-msc:18:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:18",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:18:option:c",
      "recordKey": "question:1397:ce-msc:18:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:18",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:18:option:d",
      "recordKey": "question:1397:ce-msc:18:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:18",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:19:option:a",
      "recordKey": "question:1397:ce-msc:19:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:19",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:19:option:b",
      "recordKey": "question:1397:ce-msc:19:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:19",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:19:option:c",
      "recordKey": "question:1397:ce-msc:19:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:19",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:19:option:d",
      "recordKey": "question:1397:ce-msc:19:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:19",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:20:option:a",
      "recordKey": "question:1397:ce-msc:20:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:20",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:20:option:b",
      "recordKey": "question:1397:ce-msc:20:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:20",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:20:option:c",
      "recordKey": "question:1397:ce-msc:20:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:20",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:20:option:d",
      "recordKey": "question:1397:ce-msc:20:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:20",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:21:option:a",
      "recordKey": "question:1397:ce-msc:21:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:21",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:21:option:b",
      "recordKey": "question:1397:ce-msc:21:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:21",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:21:option:c",
      "recordKey": "question:1397:ce-msc:21:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:21",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:21:option:d",
      "recordKey": "question:1397:ce-msc:21:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:21",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:22:option:a",
      "recordKey": "question:1397:ce-msc:22:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:22",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:22:option:b",
      "recordKey": "question:1397:ce-msc:22:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:22",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:22:option:c",
      "recordKey": "question:1397:ce-msc:22:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:22",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:22:option:d",
      "recordKey": "question:1397:ce-msc:22:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:22",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:23:option:a",
      "recordKey": "question:1397:ce-msc:23:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:23",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:23:option:b",
      "recordKey": "question:1397:ce-msc:23:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:23",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:23:option:c",
      "recordKey": "question:1397:ce-msc:23:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:23",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:23:option:d",
      "recordKey": "question:1397:ce-msc:23:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:23",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:24:option:a",
      "recordKey": "question:1397:ce-msc:24:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:24",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:24:option:b",
      "recordKey": "question:1397:ce-msc:24:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:24",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:24:option:c",
      "recordKey": "question:1397:ce-msc:24:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:24",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:24:option:d",
      "recordKey": "question:1397:ce-msc:24:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:24",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:25:option:a",
      "recordKey": "question:1397:ce-msc:25:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:25",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:25:option:b",
      "recordKey": "question:1397:ce-msc:25:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:25",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:25:option:c",
      "recordKey": "question:1397:ce-msc:25:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:25",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:25:option:d",
      "recordKey": "question:1397:ce-msc:25:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:25",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:26:option:a",
      "recordKey": "question:1397:ce-msc:26:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:26",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:26:option:b",
      "recordKey": "question:1397:ce-msc:26:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:26",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:26:option:c",
      "recordKey": "question:1397:ce-msc:26:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:26",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:26:option:d",
      "recordKey": "question:1397:ce-msc:26:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:26",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:27:option:a",
      "recordKey": "question:1397:ce-msc:27:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:27",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:27:option:b",
      "recordKey": "question:1397:ce-msc:27:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:27",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:27:option:c",
      "recordKey": "question:1397:ce-msc:27:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:27",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:27:option:d",
      "recordKey": "question:1397:ce-msc:27:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:27",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:28:option:a",
      "recordKey": "question:1397:ce-msc:28:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:28",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:28:option:b",
      "recordKey": "question:1397:ce-msc:28:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:28",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:28:option:c",
      "recordKey": "question:1397:ce-msc:28:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:28",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:28:option:d",
      "recordKey": "question:1397:ce-msc:28:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:28",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:29:option:a",
      "recordKey": "question:1397:ce-msc:29:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:29",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:29:option:b",
      "recordKey": "question:1397:ce-msc:29:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:29",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:29:option:c",
      "recordKey": "question:1397:ce-msc:29:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:29",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:29:option:d",
      "recordKey": "question:1397:ce-msc:29:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:29",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:30:option:a",
      "recordKey": "question:1397:ce-msc:30:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:30",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:30:option:b",
      "recordKey": "question:1397:ce-msc:30:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:30",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:30:option:c",
      "recordKey": "question:1397:ce-msc:30:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:30",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:30:option:d",
      "recordKey": "question:1397:ce-msc:30:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:30",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:31:option:a",
      "recordKey": "question:1397:ce-msc:31:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:31",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:31:option:b",
      "recordKey": "question:1397:ce-msc:31:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:31",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:31:option:c",
      "recordKey": "question:1397:ce-msc:31:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:31",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:31:option:d",
      "recordKey": "question:1397:ce-msc:31:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:31",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:32:option:a",
      "recordKey": "question:1397:ce-msc:32:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:32",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:32:option:b",
      "recordKey": "question:1397:ce-msc:32:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:32",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:32:option:c",
      "recordKey": "question:1397:ce-msc:32:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:32",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:32:option:d",
      "recordKey": "question:1397:ce-msc:32:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:32",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:33:option:a",
      "recordKey": "question:1397:ce-msc:33:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:33",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:33:option:b",
      "recordKey": "question:1397:ce-msc:33:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:33",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:33:option:c",
      "recordKey": "question:1397:ce-msc:33:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:33",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:33:option:d",
      "recordKey": "question:1397:ce-msc:33:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:33",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:34:option:a",
      "recordKey": "question:1397:ce-msc:34:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:34",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:34:option:b",
      "recordKey": "question:1397:ce-msc:34:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:34",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:34:option:c",
      "recordKey": "question:1397:ce-msc:34:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:34",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:34:option:d",
      "recordKey": "question:1397:ce-msc:34:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:34",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:35:option:a",
      "recordKey": "question:1397:ce-msc:35:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:35",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:35:option:b",
      "recordKey": "question:1397:ce-msc:35:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:35",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:35:option:c",
      "recordKey": "question:1397:ce-msc:35:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:35",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:35:option:d",
      "recordKey": "question:1397:ce-msc:35:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:35",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:36:option:a",
      "recordKey": "question:1397:ce-msc:36:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:36",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:36:option:b",
      "recordKey": "question:1397:ce-msc:36:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:36",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:36:option:c",
      "recordKey": "question:1397:ce-msc:36:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:36",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:36:option:d",
      "recordKey": "question:1397:ce-msc:36:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:36",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:37:option:a",
      "recordKey": "question:1397:ce-msc:37:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:37",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:37:option:b",
      "recordKey": "question:1397:ce-msc:37:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:37",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:37:option:c",
      "recordKey": "question:1397:ce-msc:37:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:37",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:37:option:d",
      "recordKey": "question:1397:ce-msc:37:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:37",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:38:option:a",
      "recordKey": "question:1397:ce-msc:38:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:38",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:38:option:b",
      "recordKey": "question:1397:ce-msc:38:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:38",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:38:option:c",
      "recordKey": "question:1397:ce-msc:38:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:38",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:38:option:d",
      "recordKey": "question:1397:ce-msc:38:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:38",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:39:option:a",
      "recordKey": "question:1397:ce-msc:39:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:39",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:39:option:b",
      "recordKey": "question:1397:ce-msc:39:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:39",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:39:option:c",
      "recordKey": "question:1397:ce-msc:39:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:39",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:39:option:d",
      "recordKey": "question:1397:ce-msc:39:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:39",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:40:option:a",
      "recordKey": "question:1397:ce-msc:40:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:40",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:40:option:b",
      "recordKey": "question:1397:ce-msc:40:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:40",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:40:option:c",
      "recordKey": "question:1397:ce-msc:40:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:40",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:40:option:d",
      "recordKey": "question:1397:ce-msc:40:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:40",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:41:option:a",
      "recordKey": "question:1397:ce-msc:41:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:41",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:41:option:b",
      "recordKey": "question:1397:ce-msc:41:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:41",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:41:option:c",
      "recordKey": "question:1397:ce-msc:41:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:41",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:41:option:d",
      "recordKey": "question:1397:ce-msc:41:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:41",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:42:option:a",
      "recordKey": "question:1397:ce-msc:42:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:42",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:42:option:b",
      "recordKey": "question:1397:ce-msc:42:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:42",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:42:option:c",
      "recordKey": "question:1397:ce-msc:42:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:42",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:42:option:d",
      "recordKey": "question:1397:ce-msc:42:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:42",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:43:option:a",
      "recordKey": "question:1397:ce-msc:43:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:43",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:43:option:b",
      "recordKey": "question:1397:ce-msc:43:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:43",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:43:option:c",
      "recordKey": "question:1397:ce-msc:43:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:43",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:43:option:d",
      "recordKey": "question:1397:ce-msc:43:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:43",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:44:option:a",
      "recordKey": "question:1397:ce-msc:44:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:44",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:44:option:b",
      "recordKey": "question:1397:ce-msc:44:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:44",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:44:option:c",
      "recordKey": "question:1397:ce-msc:44:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:44",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:44:option:d",
      "recordKey": "question:1397:ce-msc:44:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:44",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:45:option:a",
      "recordKey": "question:1397:ce-msc:45:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:45",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:45:option:b",
      "recordKey": "question:1397:ce-msc:45:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:45",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:45:option:c",
      "recordKey": "question:1397:ce-msc:45:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:45",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:45:option:d",
      "recordKey": "question:1397:ce-msc:45:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:45",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:46:option:a",
      "recordKey": "question:1397:ce-msc:46:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:46",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:46:option:b",
      "recordKey": "question:1397:ce-msc:46:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:46",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:46:option:c",
      "recordKey": "question:1397:ce-msc:46:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:46",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:46:option:d",
      "recordKey": "question:1397:ce-msc:46:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:46",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:47:option:a",
      "recordKey": "question:1397:ce-msc:47:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:47",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:47:option:b",
      "recordKey": "question:1397:ce-msc:47:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:47",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:47:option:c",
      "recordKey": "question:1397:ce-msc:47:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:47",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:47:option:d",
      "recordKey": "question:1397:ce-msc:47:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:47",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:48:option:a",
      "recordKey": "question:1397:ce-msc:48:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:48",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:48:option:b",
      "recordKey": "question:1397:ce-msc:48:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:48",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:48:option:c",
      "recordKey": "question:1397:ce-msc:48:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:48",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:48:option:d",
      "recordKey": "question:1397:ce-msc:48:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:48",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:49:option:a",
      "recordKey": "question:1397:ce-msc:49:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:49",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:49:option:b",
      "recordKey": "question:1397:ce-msc:49:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:49",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:49:option:c",
      "recordKey": "question:1397:ce-msc:49:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:49",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:49:option:d",
      "recordKey": "question:1397:ce-msc:49:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:49",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:50:option:a",
      "recordKey": "question:1397:ce-msc:50:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:50",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:50:option:b",
      "recordKey": "question:1397:ce-msc:50:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:50",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:50:option:c",
      "recordKey": "question:1397:ce-msc:50:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:50",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:50:option:d",
      "recordKey": "question:1397:ce-msc:50:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:50",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:51:option:a",
      "recordKey": "question:1397:ce-msc:51:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:51",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:51:option:b",
      "recordKey": "question:1397:ce-msc:51:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:51",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:51:option:c",
      "recordKey": "question:1397:ce-msc:51:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:51",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:51:option:d",
      "recordKey": "question:1397:ce-msc:51:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:51",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:52:option:a",
      "recordKey": "question:1397:ce-msc:52:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:52",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:52:option:b",
      "recordKey": "question:1397:ce-msc:52:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:52",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:52:option:c",
      "recordKey": "question:1397:ce-msc:52:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:52",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:52:option:d",
      "recordKey": "question:1397:ce-msc:52:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:52",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:53:option:a",
      "recordKey": "question:1397:ce-msc:53:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:53",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:53:option:b",
      "recordKey": "question:1397:ce-msc:53:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:53",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:53:option:c",
      "recordKey": "question:1397:ce-msc:53:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:53",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:53:option:d",
      "recordKey": "question:1397:ce-msc:53:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:53",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:54:option:a",
      "recordKey": "question:1397:ce-msc:54:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:54",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:54:option:b",
      "recordKey": "question:1397:ce-msc:54:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:54",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:54:option:c",
      "recordKey": "question:1397:ce-msc:54:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:54",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:54:option:d",
      "recordKey": "question:1397:ce-msc:54:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:54",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:55:option:a",
      "recordKey": "question:1397:ce-msc:55:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:55",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:55:option:b",
      "recordKey": "question:1397:ce-msc:55:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:55",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:55:option:c",
      "recordKey": "question:1397:ce-msc:55:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:55",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:55:option:d",
      "recordKey": "question:1397:ce-msc:55:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:55",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:56:option:a",
      "recordKey": "question:1397:ce-msc:56:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:56",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:56:option:b",
      "recordKey": "question:1397:ce-msc:56:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:56",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:56:option:c",
      "recordKey": "question:1397:ce-msc:56:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:56",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:56:option:d",
      "recordKey": "question:1397:ce-msc:56:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:56",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:57:option:a",
      "recordKey": "question:1397:ce-msc:57:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:57",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:57:option:b",
      "recordKey": "question:1397:ce-msc:57:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:57",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:57:option:c",
      "recordKey": "question:1397:ce-msc:57:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:57",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:57:option:d",
      "recordKey": "question:1397:ce-msc:57:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:57",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:58:option:a",
      "recordKey": "question:1397:ce-msc:58:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:58",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:58:option:b",
      "recordKey": "question:1397:ce-msc:58:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:58",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:58:option:c",
      "recordKey": "question:1397:ce-msc:58:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:58",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:58:option:d",
      "recordKey": "question:1397:ce-msc:58:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:58",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:59:option:a",
      "recordKey": "question:1397:ce-msc:59:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:59",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:59:option:b",
      "recordKey": "question:1397:ce-msc:59:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:59",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:59:option:c",
      "recordKey": "question:1397:ce-msc:59:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:59",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:59:option:d",
      "recordKey": "question:1397:ce-msc:59:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:59",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:60:option:a",
      "recordKey": "question:1397:ce-msc:60:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:60",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:60:option:b",
      "recordKey": "question:1397:ce-msc:60:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:60",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:60:option:c",
      "recordKey": "question:1397:ce-msc:60:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:60",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:60:option:d",
      "recordKey": "question:1397:ce-msc:60:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:60",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:61:option:a",
      "recordKey": "question:1397:ce-msc:61:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:61",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:61:option:b",
      "recordKey": "question:1397:ce-msc:61:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:61",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:61:option:c",
      "recordKey": "question:1397:ce-msc:61:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:61",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:61:option:d",
      "recordKey": "question:1397:ce-msc:61:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:61",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:62:option:a",
      "recordKey": "question:1397:ce-msc:62:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:62",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:62:option:b",
      "recordKey": "question:1397:ce-msc:62:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:62",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:62:option:c",
      "recordKey": "question:1397:ce-msc:62:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:62",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:62:option:d",
      "recordKey": "question:1397:ce-msc:62:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:62",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:63:option:a",
      "recordKey": "question:1397:ce-msc:63:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:63",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:63:option:b",
      "recordKey": "question:1397:ce-msc:63:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:63",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:63:option:c",
      "recordKey": "question:1397:ce-msc:63:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:63",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:63:option:d",
      "recordKey": "question:1397:ce-msc:63:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:63",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:64:option:a",
      "recordKey": "question:1397:ce-msc:64:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:64",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:64:option:b",
      "recordKey": "question:1397:ce-msc:64:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:64",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:64:option:c",
      "recordKey": "question:1397:ce-msc:64:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:64",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:64:option:d",
      "recordKey": "question:1397:ce-msc:64:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:64",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:65:option:a",
      "recordKey": "question:1397:ce-msc:65:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:65",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:65:option:b",
      "recordKey": "question:1397:ce-msc:65:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:65",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:65:option:c",
      "recordKey": "question:1397:ce-msc:65:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:65",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:65:option:d",
      "recordKey": "question:1397:ce-msc:65:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:65",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:66:option:a",
      "recordKey": "question:1397:ce-msc:66:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:66",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:66:option:b",
      "recordKey": "question:1397:ce-msc:66:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:66",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:66:option:c",
      "recordKey": "question:1397:ce-msc:66:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:66",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:66:option:d",
      "recordKey": "question:1397:ce-msc:66:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:66",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:67:option:a",
      "recordKey": "question:1397:ce-msc:67:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:67",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:67:option:b",
      "recordKey": "question:1397:ce-msc:67:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:67",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:67:option:c",
      "recordKey": "question:1397:ce-msc:67:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:67",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:67:option:d",
      "recordKey": "question:1397:ce-msc:67:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:67",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:68:option:a",
      "recordKey": "question:1397:ce-msc:68:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:68",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:68:option:b",
      "recordKey": "question:1397:ce-msc:68:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:68",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:68:option:c",
      "recordKey": "question:1397:ce-msc:68:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:68",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:68:option:d",
      "recordKey": "question:1397:ce-msc:68:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:68",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:69:option:a",
      "recordKey": "question:1397:ce-msc:69:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:69",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:69:option:b",
      "recordKey": "question:1397:ce-msc:69:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:69",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:69:option:c",
      "recordKey": "question:1397:ce-msc:69:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:69",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:69:option:d",
      "recordKey": "question:1397:ce-msc:69:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:69",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:70:option:a",
      "recordKey": "question:1397:ce-msc:70:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:70",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:70:option:b",
      "recordKey": "question:1397:ce-msc:70:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:70",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:70:option:c",
      "recordKey": "question:1397:ce-msc:70:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:70",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:70:option:d",
      "recordKey": "question:1397:ce-msc:70:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:70",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:71:option:a",
      "recordKey": "question:1397:ce-msc:71:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:71",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:71:option:b",
      "recordKey": "question:1397:ce-msc:71:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:71",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:71:option:c",
      "recordKey": "question:1397:ce-msc:71:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:71",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:71:option:d",
      "recordKey": "question:1397:ce-msc:71:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:71",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:72:option:a",
      "recordKey": "question:1397:ce-msc:72:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:72",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:72:option:b",
      "recordKey": "question:1397:ce-msc:72:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:72",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:72:option:c",
      "recordKey": "question:1397:ce-msc:72:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:72",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:72:option:d",
      "recordKey": "question:1397:ce-msc:72:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:72",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:73:option:a",
      "recordKey": "question:1397:ce-msc:73:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:73",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:73:option:b",
      "recordKey": "question:1397:ce-msc:73:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:73",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:73:option:c",
      "recordKey": "question:1397:ce-msc:73:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:73",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:73:option:d",
      "recordKey": "question:1397:ce-msc:73:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:73",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:74:option:a",
      "recordKey": "question:1397:ce-msc:74:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:74",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:74:option:b",
      "recordKey": "question:1397:ce-msc:74:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:74",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:74:option:c",
      "recordKey": "question:1397:ce-msc:74:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:74",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:74:option:d",
      "recordKey": "question:1397:ce-msc:74:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:74",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:75:option:a",
      "recordKey": "question:1397:ce-msc:75:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:75",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:75:option:b",
      "recordKey": "question:1397:ce-msc:75:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:75",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:75:option:c",
      "recordKey": "question:1397:ce-msc:75:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:75",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:75:option:d",
      "recordKey": "question:1397:ce-msc:75:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:75",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:76:option:a",
      "recordKey": "question:1397:ce-msc:76:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:76",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:76:option:b",
      "recordKey": "question:1397:ce-msc:76:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:76",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:76:option:c",
      "recordKey": "question:1397:ce-msc:76:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:76",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:76:option:d",
      "recordKey": "question:1397:ce-msc:76:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:76",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:77:option:a",
      "recordKey": "question:1397:ce-msc:77:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:77",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:77:option:b",
      "recordKey": "question:1397:ce-msc:77:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:77",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:77:option:c",
      "recordKey": "question:1397:ce-msc:77:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:77",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:77:option:d",
      "recordKey": "question:1397:ce-msc:77:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:77",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:78:option:a",
      "recordKey": "question:1397:ce-msc:78:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:78",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:78:option:b",
      "recordKey": "question:1397:ce-msc:78:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:78",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:78:option:c",
      "recordKey": "question:1397:ce-msc:78:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:78",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:78:option:d",
      "recordKey": "question:1397:ce-msc:78:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:78",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:79:option:a",
      "recordKey": "question:1397:ce-msc:79:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:79",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:79:option:b",
      "recordKey": "question:1397:ce-msc:79:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:79",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:79:option:c",
      "recordKey": "question:1397:ce-msc:79:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:79",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:79:option:d",
      "recordKey": "question:1397:ce-msc:79:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:79",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:80:option:a",
      "recordKey": "question:1397:ce-msc:80:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:80",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:80:option:b",
      "recordKey": "question:1397:ce-msc:80:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:80",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:80:option:c",
      "recordKey": "question:1397:ce-msc:80:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:80",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:80:option:d",
      "recordKey": "question:1397:ce-msc:80:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:80",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:81:option:a",
      "recordKey": "question:1397:ce-msc:81:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:81",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:81:option:b",
      "recordKey": "question:1397:ce-msc:81:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:81",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:81:option:c",
      "recordKey": "question:1397:ce-msc:81:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:81",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:81:option:d",
      "recordKey": "question:1397:ce-msc:81:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:81",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:82:option:a",
      "recordKey": "question:1397:ce-msc:82:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:82",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:82:option:b",
      "recordKey": "question:1397:ce-msc:82:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:82",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:82:option:c",
      "recordKey": "question:1397:ce-msc:82:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:82",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:82:option:d",
      "recordKey": "question:1397:ce-msc:82:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:82",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:83:option:a",
      "recordKey": "question:1397:ce-msc:83:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:83",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:83:option:b",
      "recordKey": "question:1397:ce-msc:83:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:83",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:83:option:c",
      "recordKey": "question:1397:ce-msc:83:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:83",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:83:option:d",
      "recordKey": "question:1397:ce-msc:83:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:83",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:84:option:a",
      "recordKey": "question:1397:ce-msc:84:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:84",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:84:option:b",
      "recordKey": "question:1397:ce-msc:84:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:84",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:84:option:c",
      "recordKey": "question:1397:ce-msc:84:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:84",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:84:option:d",
      "recordKey": "question:1397:ce-msc:84:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:84",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:85:option:a",
      "recordKey": "question:1397:ce-msc:85:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:85",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:85:option:b",
      "recordKey": "question:1397:ce-msc:85:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:85",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:85:option:c",
      "recordKey": "question:1397:ce-msc:85:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:85",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:85:option:d",
      "recordKey": "question:1397:ce-msc:85:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:85",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:86:option:a",
      "recordKey": "question:1397:ce-msc:86:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:86",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:86:option:b",
      "recordKey": "question:1397:ce-msc:86:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:86",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:86:option:c",
      "recordKey": "question:1397:ce-msc:86:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:86",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:86:option:d",
      "recordKey": "question:1397:ce-msc:86:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:86",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:87:option:a",
      "recordKey": "question:1397:ce-msc:87:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:87",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:87:option:b",
      "recordKey": "question:1397:ce-msc:87:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:87",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:87:option:c",
      "recordKey": "question:1397:ce-msc:87:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:87",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:87:option:d",
      "recordKey": "question:1397:ce-msc:87:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:87",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:88:option:a",
      "recordKey": "question:1397:ce-msc:88:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:88",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:88:option:b",
      "recordKey": "question:1397:ce-msc:88:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:88",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:88:option:c",
      "recordKey": "question:1397:ce-msc:88:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:88",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:88:option:d",
      "recordKey": "question:1397:ce-msc:88:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:88",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:89:option:a",
      "recordKey": "question:1397:ce-msc:89:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:89",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:89:option:b",
      "recordKey": "question:1397:ce-msc:89:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:89",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:89:option:c",
      "recordKey": "question:1397:ce-msc:89:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:89",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:89:option:d",
      "recordKey": "question:1397:ce-msc:89:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:89",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:90:option:a",
      "recordKey": "question:1397:ce-msc:90:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:90",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:90:option:b",
      "recordKey": "question:1397:ce-msc:90:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:90",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:90:option:c",
      "recordKey": "question:1397:ce-msc:90:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:90",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:90:option:d",
      "recordKey": "question:1397:ce-msc:90:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:90",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:91:option:a",
      "recordKey": "question:1397:ce-msc:91:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:91",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:91:option:b",
      "recordKey": "question:1397:ce-msc:91:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:91",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:91:option:c",
      "recordKey": "question:1397:ce-msc:91:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:91",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:91:option:d",
      "recordKey": "question:1397:ce-msc:91:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:91",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:92:option:a",
      "recordKey": "question:1397:ce-msc:92:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:92",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:92:option:b",
      "recordKey": "question:1397:ce-msc:92:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:92",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:92:option:c",
      "recordKey": "question:1397:ce-msc:92:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:92",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:92:option:d",
      "recordKey": "question:1397:ce-msc:92:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:92",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:93:option:a",
      "recordKey": "question:1397:ce-msc:93:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:93",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:93:option:b",
      "recordKey": "question:1397:ce-msc:93:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:93",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:93:option:c",
      "recordKey": "question:1397:ce-msc:93:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:93",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:93:option:d",
      "recordKey": "question:1397:ce-msc:93:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:93",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:94:option:a",
      "recordKey": "question:1397:ce-msc:94:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:94",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:94:option:b",
      "recordKey": "question:1397:ce-msc:94:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:94",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:94:option:c",
      "recordKey": "question:1397:ce-msc:94:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:94",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:94:option:d",
      "recordKey": "question:1397:ce-msc:94:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:94",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:95:option:a",
      "recordKey": "question:1397:ce-msc:95:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:95",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:95:option:b",
      "recordKey": "question:1397:ce-msc:95:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:95",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:95:option:c",
      "recordKey": "question:1397:ce-msc:95:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:95",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:95:option:d",
      "recordKey": "question:1397:ce-msc:95:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:95",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:96:option:a",
      "recordKey": "question:1397:ce-msc:96:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:96",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:96:option:b",
      "recordKey": "question:1397:ce-msc:96:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:96",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:96:option:c",
      "recordKey": "question:1397:ce-msc:96:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:96",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:96:option:d",
      "recordKey": "question:1397:ce-msc:96:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:96",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:97:option:a",
      "recordKey": "question:1397:ce-msc:97:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:97",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:97:option:b",
      "recordKey": "question:1397:ce-msc:97:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:97",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:97:option:c",
      "recordKey": "question:1397:ce-msc:97:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:97",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:97:option:d",
      "recordKey": "question:1397:ce-msc:97:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:97",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:98:option:a",
      "recordKey": "question:1397:ce-msc:98:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:98",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:98:option:b",
      "recordKey": "question:1397:ce-msc:98:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:98",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:98:option:c",
      "recordKey": "question:1397:ce-msc:98:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:98",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:98:option:d",
      "recordKey": "question:1397:ce-msc:98:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:98",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:99:option:a",
      "recordKey": "question:1397:ce-msc:99:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:99",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:99:option:b",
      "recordKey": "question:1397:ce-msc:99:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:99",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:99:option:c",
      "recordKey": "question:1397:ce-msc:99:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:99",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:99:option:d",
      "recordKey": "question:1397:ce-msc:99:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:99",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:100:option:a",
      "recordKey": "question:1397:ce-msc:100:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:100",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:100:option:b",
      "recordKey": "question:1397:ce-msc:100:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:100",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:100:option:c",
      "recordKey": "question:1397:ce-msc:100:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:100",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:100:option:d",
      "recordKey": "question:1397:ce-msc:100:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:100",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:101:option:a",
      "recordKey": "question:1397:ce-msc:101:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:101",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:101:option:b",
      "recordKey": "question:1397:ce-msc:101:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:101",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:101:option:c",
      "recordKey": "question:1397:ce-msc:101:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:101",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:101:option:d",
      "recordKey": "question:1397:ce-msc:101:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:101",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:102:option:a",
      "recordKey": "question:1397:ce-msc:102:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:102",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:102:option:b",
      "recordKey": "question:1397:ce-msc:102:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:102",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:102:option:c",
      "recordKey": "question:1397:ce-msc:102:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:102",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:102:option:d",
      "recordKey": "question:1397:ce-msc:102:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:102",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:103:option:a",
      "recordKey": "question:1397:ce-msc:103:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:103",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:103:option:b",
      "recordKey": "question:1397:ce-msc:103:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:103",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:103:option:c",
      "recordKey": "question:1397:ce-msc:103:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:103",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:103:option:d",
      "recordKey": "question:1397:ce-msc:103:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:103",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:104:option:a",
      "recordKey": "question:1397:ce-msc:104:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:104",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:104:option:b",
      "recordKey": "question:1397:ce-msc:104:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:104",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:104:option:c",
      "recordKey": "question:1397:ce-msc:104:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:104",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:104:option:d",
      "recordKey": "question:1397:ce-msc:104:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:104",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:105:option:a",
      "recordKey": "question:1397:ce-msc:105:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:105",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:105:option:b",
      "recordKey": "question:1397:ce-msc:105:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:105",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:105:option:c",
      "recordKey": "question:1397:ce-msc:105:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:105",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:105:option:d",
      "recordKey": "question:1397:ce-msc:105:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:105",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:106:option:a",
      "recordKey": "question:1397:ce-msc:106:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:106",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:106:option:b",
      "recordKey": "question:1397:ce-msc:106:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:106",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:106:option:c",
      "recordKey": "question:1397:ce-msc:106:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:106",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:106:option:d",
      "recordKey": "question:1397:ce-msc:106:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:106",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:107:option:a",
      "recordKey": "question:1397:ce-msc:107:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:107",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:107:option:b",
      "recordKey": "question:1397:ce-msc:107:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:107",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:107:option:c",
      "recordKey": "question:1397:ce-msc:107:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:107",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:107:option:d",
      "recordKey": "question:1397:ce-msc:107:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:107",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:108:option:a",
      "recordKey": "question:1397:ce-msc:108:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:108",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:108:option:b",
      "recordKey": "question:1397:ce-msc:108:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:108",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:108:option:c",
      "recordKey": "question:1397:ce-msc:108:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:108",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:108:option:d",
      "recordKey": "question:1397:ce-msc:108:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:108",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:109:option:a",
      "recordKey": "question:1397:ce-msc:109:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:109",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:109:option:b",
      "recordKey": "question:1397:ce-msc:109:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:109",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:109:option:c",
      "recordKey": "question:1397:ce-msc:109:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:109",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:109:option:d",
      "recordKey": "question:1397:ce-msc:109:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:109",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:110:option:a",
      "recordKey": "question:1397:ce-msc:110:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:110",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:110:option:b",
      "recordKey": "question:1397:ce-msc:110:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:110",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:110:option:c",
      "recordKey": "question:1397:ce-msc:110:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:110",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:110:option:d",
      "recordKey": "question:1397:ce-msc:110:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:110",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:111:option:a",
      "recordKey": "question:1397:ce-msc:111:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:111",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:111:option:b",
      "recordKey": "question:1397:ce-msc:111:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:111",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:111:option:c",
      "recordKey": "question:1397:ce-msc:111:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:111",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:111:option:d",
      "recordKey": "question:1397:ce-msc:111:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:111",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:112:option:a",
      "recordKey": "question:1397:ce-msc:112:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:112",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:112:option:b",
      "recordKey": "question:1397:ce-msc:112:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:112",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:112:option:c",
      "recordKey": "question:1397:ce-msc:112:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:112",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:112:option:d",
      "recordKey": "question:1397:ce-msc:112:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:112",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:113:option:a",
      "recordKey": "question:1397:ce-msc:113:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:113",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:113:option:b",
      "recordKey": "question:1397:ce-msc:113:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:113",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:113:option:c",
      "recordKey": "question:1397:ce-msc:113:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:113",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:113:option:d",
      "recordKey": "question:1397:ce-msc:113:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:113",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:114:option:a",
      "recordKey": "question:1397:ce-msc:114:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:114",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:114:option:b",
      "recordKey": "question:1397:ce-msc:114:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:114",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:114:option:c",
      "recordKey": "question:1397:ce-msc:114:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:114",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:114:option:d",
      "recordKey": "question:1397:ce-msc:114:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:114",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:115:option:a",
      "recordKey": "question:1397:ce-msc:115:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:115",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:115:option:b",
      "recordKey": "question:1397:ce-msc:115:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:115",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:115:option:c",
      "recordKey": "question:1397:ce-msc:115:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:115",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:115:option:d",
      "recordKey": "question:1397:ce-msc:115:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:115",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:116:option:a",
      "recordKey": "question:1397:ce-msc:116:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:116",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:116:option:b",
      "recordKey": "question:1397:ce-msc:116:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:116",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:116:option:c",
      "recordKey": "question:1397:ce-msc:116:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:116",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:116:option:d",
      "recordKey": "question:1397:ce-msc:116:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:116",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:117:option:a",
      "recordKey": "question:1397:ce-msc:117:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:117",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:117:option:b",
      "recordKey": "question:1397:ce-msc:117:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:117",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:117:option:c",
      "recordKey": "question:1397:ce-msc:117:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:117",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:117:option:d",
      "recordKey": "question:1397:ce-msc:117:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:117",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:118:option:a",
      "recordKey": "question:1397:ce-msc:118:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:118",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:118:option:b",
      "recordKey": "question:1397:ce-msc:118:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:118",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:118:option:c",
      "recordKey": "question:1397:ce-msc:118:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:118",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:118:option:d",
      "recordKey": "question:1397:ce-msc:118:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:118",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:119:option:a",
      "recordKey": "question:1397:ce-msc:119:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:119",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:119:option:b",
      "recordKey": "question:1397:ce-msc:119:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:119",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:119:option:c",
      "recordKey": "question:1397:ce-msc:119:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:119",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:119:option:d",
      "recordKey": "question:1397:ce-msc:119:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:119",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:120:option:a",
      "recordKey": "question:1397:ce-msc:120:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:120",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:120:option:b",
      "recordKey": "question:1397:ce-msc:120:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:120",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:120:option:c",
      "recordKey": "question:1397:ce-msc:120:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:120",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:120:option:d",
      "recordKey": "question:1397:ce-msc:120:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:120",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:121:option:a",
      "recordKey": "question:1397:ce-msc:121:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:121",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:121:option:b",
      "recordKey": "question:1397:ce-msc:121:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:121",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:121:option:c",
      "recordKey": "question:1397:ce-msc:121:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:121",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:121:option:d",
      "recordKey": "question:1397:ce-msc:121:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:121",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:122:option:a",
      "recordKey": "question:1397:ce-msc:122:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:122",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:122:option:b",
      "recordKey": "question:1397:ce-msc:122:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:122",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:122:option:c",
      "recordKey": "question:1397:ce-msc:122:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:122",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:122:option:d",
      "recordKey": "question:1397:ce-msc:122:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:122",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:123:option:a",
      "recordKey": "question:1397:ce-msc:123:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:123",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:123:option:b",
      "recordKey": "question:1397:ce-msc:123:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:123",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:123:option:c",
      "recordKey": "question:1397:ce-msc:123:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:123",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:123:option:d",
      "recordKey": "question:1397:ce-msc:123:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:123",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:124:option:a",
      "recordKey": "question:1397:ce-msc:124:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:124",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:124:option:b",
      "recordKey": "question:1397:ce-msc:124:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:124",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:124:option:c",
      "recordKey": "question:1397:ce-msc:124:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:124",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:124:option:d",
      "recordKey": "question:1397:ce-msc:124:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:124",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:125:option:a",
      "recordKey": "question:1397:ce-msc:125:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:125",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:125:option:b",
      "recordKey": "question:1397:ce-msc:125:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:125",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:125:option:c",
      "recordKey": "question:1397:ce-msc:125:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:125",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:125:option:d",
      "recordKey": "question:1397:ce-msc:125:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:125",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:126:option:a",
      "recordKey": "question:1397:ce-msc:126:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:126",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:126:option:b",
      "recordKey": "question:1397:ce-msc:126:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:126",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:126:option:c",
      "recordKey": "question:1397:ce-msc:126:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:126",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:126:option:d",
      "recordKey": "question:1397:ce-msc:126:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:126",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:127:option:a",
      "recordKey": "question:1397:ce-msc:127:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:127",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:127:option:b",
      "recordKey": "question:1397:ce-msc:127:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:127",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:127:option:c",
      "recordKey": "question:1397:ce-msc:127:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:127",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:127:option:d",
      "recordKey": "question:1397:ce-msc:127:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:127",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:128:option:a",
      "recordKey": "question:1397:ce-msc:128:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:128",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:128:option:b",
      "recordKey": "question:1397:ce-msc:128:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:128",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:128:option:c",
      "recordKey": "question:1397:ce-msc:128:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:128",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:128:option:d",
      "recordKey": "question:1397:ce-msc:128:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:128",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:129:option:a",
      "recordKey": "question:1397:ce-msc:129:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:129",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:129:option:b",
      "recordKey": "question:1397:ce-msc:129:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:129",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:129:option:c",
      "recordKey": "question:1397:ce-msc:129:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:129",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:129:option:d",
      "recordKey": "question:1397:ce-msc:129:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:129",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:130:option:a",
      "recordKey": "question:1397:ce-msc:130:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:130",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:130:option:b",
      "recordKey": "question:1397:ce-msc:130:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:130",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:130:option:c",
      "recordKey": "question:1397:ce-msc:130:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:130",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:130:option:d",
      "recordKey": "question:1397:ce-msc:130:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:130",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:131:option:a",
      "recordKey": "question:1397:ce-msc:131:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:131",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:131:option:b",
      "recordKey": "question:1397:ce-msc:131:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:131",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:131:option:c",
      "recordKey": "question:1397:ce-msc:131:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:131",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:131:option:d",
      "recordKey": "question:1397:ce-msc:131:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:131",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:132:option:a",
      "recordKey": "question:1397:ce-msc:132:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:132",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:132:option:b",
      "recordKey": "question:1397:ce-msc:132:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:132",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:132:option:c",
      "recordKey": "question:1397:ce-msc:132:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:132",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:132:option:d",
      "recordKey": "question:1397:ce-msc:132:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:132",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:133:option:a",
      "recordKey": "question:1397:ce-msc:133:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:133",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:133:option:b",
      "recordKey": "question:1397:ce-msc:133:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:133",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:133:option:c",
      "recordKey": "question:1397:ce-msc:133:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:133",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:133:option:d",
      "recordKey": "question:1397:ce-msc:133:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:133",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:134:option:a",
      "recordKey": "question:1397:ce-msc:134:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:134",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:134:option:b",
      "recordKey": "question:1397:ce-msc:134:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:134",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:134:option:c",
      "recordKey": "question:1397:ce-msc:134:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:134",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:134:option:d",
      "recordKey": "question:1397:ce-msc:134:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:134",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:135:option:a",
      "recordKey": "question:1397:ce-msc:135:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:135",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:135:option:b",
      "recordKey": "question:1397:ce-msc:135:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:135",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:135:option:c",
      "recordKey": "question:1397:ce-msc:135:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:135",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:135:option:d",
      "recordKey": "question:1397:ce-msc:135:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:135",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:136:option:a",
      "recordKey": "question:1397:ce-msc:136:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:136",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:136:option:b",
      "recordKey": "question:1397:ce-msc:136:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:136",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:136:option:c",
      "recordKey": "question:1397:ce-msc:136:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:136",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:136:option:d",
      "recordKey": "question:1397:ce-msc:136:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:136",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:137:option:a",
      "recordKey": "question:1397:ce-msc:137:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:137",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:137:option:b",
      "recordKey": "question:1397:ce-msc:137:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:137",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:137:option:c",
      "recordKey": "question:1397:ce-msc:137:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:137",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:137:option:d",
      "recordKey": "question:1397:ce-msc:137:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:137",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:138:option:a",
      "recordKey": "question:1397:ce-msc:138:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:138",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:138:option:b",
      "recordKey": "question:1397:ce-msc:138:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:138",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:138:option:c",
      "recordKey": "question:1397:ce-msc:138:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:138",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:138:option:d",
      "recordKey": "question:1397:ce-msc:138:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:138",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:139:option:a",
      "recordKey": "question:1397:ce-msc:139:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:139",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:139:option:b",
      "recordKey": "question:1397:ce-msc:139:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:139",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:139:option:c",
      "recordKey": "question:1397:ce-msc:139:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:139",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:139:option:d",
      "recordKey": "question:1397:ce-msc:139:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:139",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:140:option:a",
      "recordKey": "question:1397:ce-msc:140:option:a@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:140",
      "optionKey": "a",
      "order": 1,
      "text": {
        "en": "Option A",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:140:option:b",
      "recordKey": "question:1397:ce-msc:140:option:b@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:140",
      "optionKey": "b",
      "order": 2,
      "text": {
        "en": "Option B",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:140:option:c",
      "recordKey": "question:1397:ce-msc:140:option:c@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:140",
      "optionKey": "c",
      "order": 3,
      "text": {
        "en": "Option C",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    },
    {
      "id": "question:1397:ce-msc:140:option:d",
      "recordKey": "question:1397:ce-msc:140:option:d@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [],
      "primarySourceId": null,
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": null,
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:140",
      "optionKey": "d",
      "order": 4,
      "text": {
        "en": "Option D",
        "primaryLocale": "en",
        "translationStatus": "not-applicable"
      },
      "imageAssetIds": []
    }
  ]
};
  var answerDataset = {
  "datasetId": "answer:key:1397:legacy",
  "datasetType": "official-answers",
  "schemaVersion": 1,
  "version": 1,
  "testOnly": false,
  "records": [
    {
      "id": "answer:1397:1:legacy-key",
      "recordKey": "answer:1397:1:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:1",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:1:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:2:legacy-key",
      "recordKey": "answer:1397:2:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:2",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:2:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:3:legacy-key",
      "recordKey": "answer:1397:3:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:3",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:3:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:4:legacy-key",
      "recordKey": "answer:1397:4:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:4",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:4:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:5:legacy-key",
      "recordKey": "answer:1397:5:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:5",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:5:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:6:legacy-key",
      "recordKey": "answer:1397:6:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:6",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:6:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:7:legacy-key",
      "recordKey": "answer:1397:7:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:7",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:7:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:8:legacy-key",
      "recordKey": "answer:1397:8:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:8",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:8:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:9:legacy-key",
      "recordKey": "answer:1397:9:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:9",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:9:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:10:legacy-key",
      "recordKey": "answer:1397:10:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:10",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:10:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:11:legacy-key",
      "recordKey": "answer:1397:11:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:11",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:11:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:12:legacy-key",
      "recordKey": "answer:1397:12:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:12",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:12:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:13:legacy-key",
      "recordKey": "answer:1397:13:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:13",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:13:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:14:legacy-key",
      "recordKey": "answer:1397:14:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:14",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:14:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:15:legacy-key",
      "recordKey": "answer:1397:15:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:15",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:15:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:16:legacy-key",
      "recordKey": "answer:1397:16:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:16",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:16:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:17:legacy-key",
      "recordKey": "answer:1397:17:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:17",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:17:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:18:legacy-key",
      "recordKey": "answer:1397:18:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:18",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:18:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:19:legacy-key",
      "recordKey": "answer:1397:19:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:19",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:19:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:20:legacy-key",
      "recordKey": "answer:1397:20:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:20",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:20:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:21:legacy-key",
      "recordKey": "answer:1397:21:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:21",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:21:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:22:legacy-key",
      "recordKey": "answer:1397:22:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:22",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:22:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:23:legacy-key",
      "recordKey": "answer:1397:23:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:23",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:23:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:24:legacy-key",
      "recordKey": "answer:1397:24:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:24",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:24:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:25:legacy-key",
      "recordKey": "answer:1397:25:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:25",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:25:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:26:legacy-key",
      "recordKey": "answer:1397:26:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:26",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:26:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:27:legacy-key",
      "recordKey": "answer:1397:27:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:27",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:27:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:28:legacy-key",
      "recordKey": "answer:1397:28:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:28",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:28:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:29:legacy-key",
      "recordKey": "answer:1397:29:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:29",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:29:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:30:legacy-key",
      "recordKey": "answer:1397:30:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:30",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:30:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:31:legacy-key",
      "recordKey": "answer:1397:31:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:31",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:31:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:32:legacy-key",
      "recordKey": "answer:1397:32:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:32",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:32:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:33:legacy-key",
      "recordKey": "answer:1397:33:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:33",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:33:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:34:legacy-key",
      "recordKey": "answer:1397:34:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:34",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:34:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:35:legacy-key",
      "recordKey": "answer:1397:35:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:35",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:35:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:36:legacy-key",
      "recordKey": "answer:1397:36:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:36",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:36:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:37:legacy-key",
      "recordKey": "answer:1397:37:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:37",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:37:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:38:legacy-key",
      "recordKey": "answer:1397:38:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:38",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:38:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:39:legacy-key",
      "recordKey": "answer:1397:39:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:39",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:39:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:40:legacy-key",
      "recordKey": "answer:1397:40:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:40",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:40:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:41:legacy-key",
      "recordKey": "answer:1397:41:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:41",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:41:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:42:legacy-key",
      "recordKey": "answer:1397:42:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:42",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:42:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:43:legacy-key",
      "recordKey": "answer:1397:43:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:43",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:43:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:44:legacy-key",
      "recordKey": "answer:1397:44:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:44",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:44:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:45:legacy-key",
      "recordKey": "answer:1397:45:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:45",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:45:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:46:legacy-key",
      "recordKey": "answer:1397:46:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:46",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:46:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:47:legacy-key",
      "recordKey": "answer:1397:47:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:47",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:47:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:48:legacy-key",
      "recordKey": "answer:1397:48:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:48",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:48:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:49:legacy-key",
      "recordKey": "answer:1397:49:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:49",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:49:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:50:legacy-key",
      "recordKey": "answer:1397:50:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:50",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:50:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:51:legacy-key",
      "recordKey": "answer:1397:51:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:51",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:51:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:52:legacy-key",
      "recordKey": "answer:1397:52:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:52",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:52:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:53:legacy-key",
      "recordKey": "answer:1397:53:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:53",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:53:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:54:legacy-key",
      "recordKey": "answer:1397:54:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:54",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:54:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:55:legacy-key",
      "recordKey": "answer:1397:55:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:55",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:55:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:56:legacy-key",
      "recordKey": "answer:1397:56:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:56",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:56:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:57:legacy-key",
      "recordKey": "answer:1397:57:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:57",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:57:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:58:legacy-key",
      "recordKey": "answer:1397:58:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:58",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:58:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:59:legacy-key",
      "recordKey": "answer:1397:59:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:59",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:59:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:60:legacy-key",
      "recordKey": "answer:1397:60:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:60",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:60:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:61:legacy-key",
      "recordKey": "answer:1397:61:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:61",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:61:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:62:legacy-key",
      "recordKey": "answer:1397:62:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:62",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:62:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:63:legacy-key",
      "recordKey": "answer:1397:63:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:63",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:63:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:64:legacy-key",
      "recordKey": "answer:1397:64:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:64",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:64:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:65:legacy-key",
      "recordKey": "answer:1397:65:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:65",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:65:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:66:legacy-key",
      "recordKey": "answer:1397:66:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:66",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:66:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:67:legacy-key",
      "recordKey": "answer:1397:67:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:67",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:67:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:68:legacy-key",
      "recordKey": "answer:1397:68:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:68",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:68:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:69:legacy-key",
      "recordKey": "answer:1397:69:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:69",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:69:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:70:legacy-key",
      "recordKey": "answer:1397:70:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:70",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:70:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:71:legacy-key",
      "recordKey": "answer:1397:71:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:71",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:71:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:72:legacy-key",
      "recordKey": "answer:1397:72:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:72",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:72:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:73:legacy-key",
      "recordKey": "answer:1397:73:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:73",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:73:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:74:legacy-key",
      "recordKey": "answer:1397:74:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:74",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:74:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:75:legacy-key",
      "recordKey": "answer:1397:75:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:75",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:75:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:76:legacy-key",
      "recordKey": "answer:1397:76:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:76",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:76:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:77:legacy-key",
      "recordKey": "answer:1397:77:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:77",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:77:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:78:legacy-key",
      "recordKey": "answer:1397:78:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:78",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:78:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:79:legacy-key",
      "recordKey": "answer:1397:79:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:79",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:79:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:80:legacy-key",
      "recordKey": "answer:1397:80:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:80",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:80:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:81:legacy-key",
      "recordKey": "answer:1397:81:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:81",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:81:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:82:legacy-key",
      "recordKey": "answer:1397:82:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:82",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:82:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:83:legacy-key",
      "recordKey": "answer:1397:83:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:83",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:83:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:84:legacy-key",
      "recordKey": "answer:1397:84:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:84",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:84:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:85:legacy-key",
      "recordKey": "answer:1397:85:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:85",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:85:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:86:legacy-key",
      "recordKey": "answer:1397:86:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:86",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:86:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:87:legacy-key",
      "recordKey": "answer:1397:87:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:87",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:87:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:88:legacy-key",
      "recordKey": "answer:1397:88:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:88",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:88:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:89:legacy-key",
      "recordKey": "answer:1397:89:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:89",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:89:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:90:legacy-key",
      "recordKey": "answer:1397:90:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:90",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:90:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:91:legacy-key",
      "recordKey": "answer:1397:91:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:91",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:91:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:92:legacy-key",
      "recordKey": "answer:1397:92:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:92",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:92:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:93:legacy-key",
      "recordKey": "answer:1397:93:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:93",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:93:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:94:legacy-key",
      "recordKey": "answer:1397:94:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:94",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:94:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:95:legacy-key",
      "recordKey": "answer:1397:95:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:95",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:95:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:96:legacy-key",
      "recordKey": "answer:1397:96:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:96",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:96:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:97:legacy-key",
      "recordKey": "answer:1397:97:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:97",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:97:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:98:legacy-key",
      "recordKey": "answer:1397:98:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:98",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:98:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:99:legacy-key",
      "recordKey": "answer:1397:99:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:99",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:99:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:100:legacy-key",
      "recordKey": "answer:1397:100:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:100",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:100:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:101:legacy-key",
      "recordKey": "answer:1397:101:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:101",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:101:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:102:legacy-key",
      "recordKey": "answer:1397:102:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:102",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:102:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:103:legacy-key",
      "recordKey": "answer:1397:103:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:103",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:103:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:104:legacy-key",
      "recordKey": "answer:1397:104:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:104",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:104:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:105:legacy-key",
      "recordKey": "answer:1397:105:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:105",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:105:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:106:legacy-key",
      "recordKey": "answer:1397:106:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:106",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:106:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:107:legacy-key",
      "recordKey": "answer:1397:107:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:107",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:107:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:108:legacy-key",
      "recordKey": "answer:1397:108:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:108",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:108:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:109:legacy-key",
      "recordKey": "answer:1397:109:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:109",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:109:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:110:legacy-key",
      "recordKey": "answer:1397:110:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:110",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:110:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:111:legacy-key",
      "recordKey": "answer:1397:111:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:111",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:111:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:112:legacy-key",
      "recordKey": "answer:1397:112:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:112",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:112:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:113:legacy-key",
      "recordKey": "answer:1397:113:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:113",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:113:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:114:legacy-key",
      "recordKey": "answer:1397:114:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:114",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:114:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:115:legacy-key",
      "recordKey": "answer:1397:115:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:115",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:115:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:116:legacy-key",
      "recordKey": "answer:1397:116:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:116",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:116:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:117:legacy-key",
      "recordKey": "answer:1397:117:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:117",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:117:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:118:legacy-key",
      "recordKey": "answer:1397:118:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:118",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:118:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:119:legacy-key",
      "recordKey": "answer:1397:119:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:119",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:119:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:120:legacy-key",
      "recordKey": "answer:1397:120:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:120",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:120:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:121:legacy-key",
      "recordKey": "answer:1397:121:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:121",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:121:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:122:legacy-key",
      "recordKey": "answer:1397:122:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:122",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:122:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:123:legacy-key",
      "recordKey": "answer:1397:123:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:123",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:123:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:124:legacy-key",
      "recordKey": "answer:1397:124:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:124",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:124:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:125:legacy-key",
      "recordKey": "answer:1397:125:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:125",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:125:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:126:legacy-key",
      "recordKey": "answer:1397:126:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:126",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:126:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:127:legacy-key",
      "recordKey": "answer:1397:127:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:127",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:127:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:128:legacy-key",
      "recordKey": "answer:1397:128:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:128",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:128:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:129:legacy-key",
      "recordKey": "answer:1397:129:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:129",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:129:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:130:legacy-key",
      "recordKey": "answer:1397:130:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:130",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:130:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:131:legacy-key",
      "recordKey": "answer:1397:131:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:131",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:131:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:132:legacy-key",
      "recordKey": "answer:1397:132:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:132",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:132:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:133:legacy-key",
      "recordKey": "answer:1397:133:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:133",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:133:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:134:legacy-key",
      "recordKey": "answer:1397:134:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:134",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:134:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:135:legacy-key",
      "recordKey": "answer:1397:135:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:135",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:135:option:c"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:136:legacy-key",
      "recordKey": "answer:1397:136:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:136",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:136:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:137:legacy-key",
      "recordKey": "answer:1397:137:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:137",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:137:option:a"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:138:legacy-key",
      "recordKey": "answer:1397:138:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:138",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:138:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:139:legacy-key",
      "recordKey": "answer:1397:139:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:139",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:139:option:d"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    },
    {
      "id": "answer:1397:140:legacy-key",
      "recordKey": "answer:1397:140:legacy-key@1",
      "schemaVersion": 1,
      "version": 1,
      "verificationStatus": "not-applicable",
      "publicationStatus": "published",
      "educationalApproval": {
        "status": "not-applicable",
        "reviewerRole": null,
        "reviewedAt": null,
        "reviewContractVersion": null
      },
      "sourceIds": [
        "source:1397:key:legacy"
      ],
      "primarySourceId": "source:1397:key:legacy",
      "sourcePage": null,
      "sourceUrl": null,
      "provenanceNotes": "Extracted from legacy prototype answer array. Not independently verified.",
      "createdAt": "2026-07-15T00:00:00.000Z",
      "updatedAt": "2026-07-15T00:00:00.000Z",
      "questionId": "question:1397:ce-msc:140",
      "answerKeySourceId": "source:1397:key:legacy",
      "acceptedOptionIds": [
        "question:1397:ce-msc:140:option:b"
      ],
      "answerStatus": "verified",
      "effectiveDate": null,
      "officialNote": null,
      "supersededByCorrectionId": null
    }
  ]
};

  var registrations = [];
  var sourceRegistration = app.content.sourceRegistry.register(sourceDataset);
  registrations.push({ datasetId: sourceDataset.datasetId, registry: "source", ok: sourceRegistration.ok, code: sourceRegistration.code || null });
  [sourceDataset, questionDataset, optionDataset, answerDataset].forEach(function(ds) {
    var result = app.content.registry.register(ds);
    registrations.push({ datasetId: ds.datasetId, registry: "content", ok: result.ok, code: result.code || null });
  });

  app.register("content", "exam" + 1397, {
    config: config,
    registrations: registrations,
    year: 1397
  });
})(window);
